from setuptools import setup, find_packages

setup(
    name='homework_exercise',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Grzegoz Bokota',
    description='A homework package'
)